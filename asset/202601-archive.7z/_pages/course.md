---
layout: page
permalink: /course/
title: Course
description: My teaching :D
nav: true
nav_order: 3
dropdown: true
parent: root
children: 
    - title: 数字系统原理与实践[信班](25'春)
      permalink: /digital_logic_lab/
    - title: divider
    - title: 人工智能芯片：设计与实践(25'秋)
      permalink: /adap25/
    - title: divider
    - title: 嵌入式系统编程与实践(25'秋)
      permalink: /esp25/
    - title: divider
    - title: 人工智能与集成电路[通班](23'秋)
      permalink: /aichip2023/
    - title: divider
    - title: 人工智能芯片设计导论(23'秋)
      permalink: /aiic2023/
---

### 研究生课程
  - 人工智能芯片：设计与实践 ([25'fall](/adap25/))
  - 嵌入式系统编程与实践 ([25'fall](/esp25/))

### 本科生课程
  - 人工智能与集成电路[通班]([23'fall](/aiic23fall/))
  - 人工智能芯片设计导论 ([23'fall](/aichip23fall/))
  - 数字系统原理与实践（信班）([25'spring](/digital25spring/))
