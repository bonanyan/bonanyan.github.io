---
layout: page
permalink: /info/
title: Others
description: Others
nav: true
nav_order: 6
dropdown: true
parent: root
children: 
    - title: Publication
      permalink: /publications/
    - title: divider
    - title: Recruit
      permalink: /recruit/
    - title: divider
    - title: PhD Career Guide
      permalink: /phdguide/
---